
FREE APP

Created by WebIntoApp.com on Tuesday 2nd of November 2021 09:41:30 AM.

Release APK & App Bundle (AAB) ready to be submitted to Google Play Store 
and to any other APK / AAB store over the internet.

-------------------------------------
App ID:			30621
App Key:		voeQMNtaqkwbqFVXNtrPPvlyRPVLniPx
App Name:		LUKABOYホームページ
App Version:	2.0
Package:		luka.hp.app
Mode:			Free App
-------------------------------------

Your free app is ready, you can now publish it to the 
google play store and to any apk app store on the internet.

-------------------------------------
Please note, your app is under a FREE mode, you can always 
convert it to your own dedicated and branded mobile app for 
Android and iOS with all the premium features at:

https://www.webintoapp.com/author/apps/30621/edit?cmd=app-switcher

-------------------------------------
Here are some useful links:
-------------------------------------

You can edit your app at:
https://www.webintoapp.com/author/apps

Get installs statistics at:
https://www.webintoapp.com/author/stats?appid=30621

The Author Area:
https://www.webintoapp.com/author/dashboard

-------------------------------------
WebIntoApp.com Team.
https://www.webintoapp.com
-------------------------------------
